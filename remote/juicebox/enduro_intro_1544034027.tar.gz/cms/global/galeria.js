{
	galeria_titulo: 'GALERÍA',
	galeria_descripcion: 'Conoce algunos de nuestros desarrollos y descubre porque construir con nosotros es la mejor decisión.',
	album: [
		{
			titulo: 'CASA 1:',
			imagenes: [
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542933596_casa-1-imagen-01.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542933603_casa-1-imagen-02.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542933615_casa-1-imagen-03.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542933628_casa-1-imagen-04.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542933633_casa-1-imagen-05.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542933637_casa-1-imagen-06.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542933643_casa-1-imagen-07.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542933649_casa-1-imagen-08.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542933654_casa-1-imagen-09.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542933660_casa-1-imagen-10.jpg'
				}
			]
		},
		{
			titulo: 'CASA 2:',
			imagenes: [
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542934130_casa-2-imagen-01.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542934134_casa-2-imagen-02.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542934139_casa-2-imagen-03.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542934144_casa-2-imagen-04.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542934148_casa-2-imagen-05.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542934151_casa-2-imagen-06.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542934156_casa-2-imagen-07.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542934160_casa-2-imagen-08.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542934163_casa-2-imagen-09.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1542934166_casa-2-imagen-10.jpg'
				}
			]
		},
		{
			titulo: 'CASA 3:',
			imagenes: [
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258371_casa-3-imagen-01.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258375_casa-3-imagen-02.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258379_casa-3-imagen-03.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258384_casa-3-imagen-04.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258387_casa-3-imagen-05.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258390_casa-3-imagen-06.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258396_casa-3-imagen-07.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258398_casa-3-imagen-08.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258402_casa-3-imagen-09.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258406_casa-3-imagen-10.jpg'
				}
			]
		},
		{
			titulo: 'CASA 4:',
			imagenes: [
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258424_casa-4-imagen-01.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258427_casa-4-imagen-02.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258430_casa-4-imagen-03.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258433_casa-4-imagen-04.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258436_casa-4-imagen-05.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258438_casa-4-imagen-06.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258461_casa-4-imagen-07.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258464_casa-4-imagen-08.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258466_casa-4-imagen-09.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258469_casa-4-imagen-10.jpg'
				}
			]
		},
		{
			titulo: 'CASA 5:',
			imagenes: [
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258489_casa-5-imagen-01.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258493_casa-5-imagen-02.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258496_casa-5-imagen-03.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258498_casa-5-imagen-04.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258501_casa-5-imagen-05.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258504_casa-5-imagen-06.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258510_casa-5-imagen-07.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258512_casa-5-imagen-08.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258514_casa-5-imagen-09.jpg'
				},
				{
					$imagen_type: 'image',
					imagen: '/remote/direct_uploads/1543258516_casa-5-imagen-10.jpg'
				}
			]
		}
	]
}