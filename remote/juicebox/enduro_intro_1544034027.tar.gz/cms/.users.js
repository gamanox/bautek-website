({
	users: [
		{
			username: 'admin',
			tags: [],
			salt: '0317aa1740dabfdd85ce0857eb4e0ef1',
			hash: 'bfccbde825872b4ca21c7ad8154c62b5e41726e51ae8ed528eee225aac334e23',
			user_created_timestamp: 1540404334246
		}
	]
})