({
	showcase: {
		slides: [
			{
				$slide_imagen_type: 'image',
				slide_imagen: '/remote/direct_uploads/1543518773_home-full.jpg',
				titulo: 'EN BAUTEK',
				subtitulo_renglon_1: 'CONSTRUÍMOS LA CASA',
				subtitulo_renglon_2: 'DE TUS SUEÑOS',
				descripcion_renglon_1: 'Comprueba que somos la mejor opción para construir tu hogar en Saltillo.',
				descripcion_renglon_2: '',
				activar_boton: true,
				boton_texto: 'CONOCER MÁS',
				boton_link: '/loquehacemos'
			},
			{
				$slide_imagen_type: 'image',
				slide_imagen: '/remote/direct_uploads/1543519391_casa-1-full.jpg',
				titulo: '',
				subtitulo_renglon_1: 'CASA DE UN PISO',
				subtitulo_renglon_2: 'EN HABITA',
				descripcion_renglon_1: '190 m2 de construcción. 2 recámaras 2 1/2 baños.',
				descripcion_renglon_2: 'Inversión: $ 3’050,000',
				activar_boton: true,
				boton_texto: 'CONOCER MÁS',
				boton_link: '/inmueble/casa-habita-1'
			},
			{
				$slide_imagen_type: 'image',
				slide_imagen: '/remote/direct_uploads/1543519482_casa-2-full.jpg',
				titulo: '',
				subtitulo_renglon_1: 'CASA DE DOS PISOS',
				subtitulo_renglon_2: 'EN HABITA',
				descripcion_renglon_1: '242 m2 de construcción. 3 recámaras 3 1/2 baños.',
				descripcion_renglon_2: 'Inversión: $ 3’750,000',
				activar_boton: true,
				boton_texto: 'CONOCER MÁS',
				boton_link: '/inmueble/casa-habita-2'
			},
			{
				$slide_imagen_type: 'image',
				slide_imagen: '/remote/direct_uploads/1543519568_alcantara-full.jpg',
				titulo: 'RINCÓN DE ALCÁNTARA.',
				subtitulo_renglon_1: 'DONDE SE CREARÁN',
				subtitulo_renglon_2: 'NUEVOS RECUERDOS',
				descripcion_renglon_1: 'PREVENTA: Casas desde  $3’500,000',
				descripcion_renglon_2: 'Vive los mejores momentos de tu vida en tu nueva casa',
				activar_boton: true,
				boton_texto: 'CONOCER MÁS',
				boton_link: '/rincon-de-alcantara'
			}
		]
	}
})